#include<stdio.h>
#include"libi.h"
main(){
	perfeito(6);
}


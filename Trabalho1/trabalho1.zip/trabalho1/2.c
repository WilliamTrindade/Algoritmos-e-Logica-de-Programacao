#include<stdio.h>
#include"libi.h"
main(){
	verifica();
}

#include<stdio.h>
#include"libi.h"
main(){
	calcule(1);
}
